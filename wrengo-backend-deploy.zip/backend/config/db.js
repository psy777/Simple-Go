const mongoose = require('mongoose');
require('dotenv').config({ path: '../.env' }); // Make sure .env variables are loaded from the backend directory

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('MongoDB Connected...');
  } catch (err) {
    console.error('MongoDB connection error:', err.message);
    // Exit process with failure
    process.exit(1);
  }
};

module.exports = connectDB;
